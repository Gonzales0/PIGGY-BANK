package com.example.projectpiggybank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    TextView loginBTN;
    EditText rFname, rUsername, rPhonenum, rEmail,rPass, rCPass;
    Button regisBTN;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        rFname = findViewById(R.id.FullnameET) ;
        rUsername = findViewById(R.id.UsernameET) ;
        rPhonenum = findViewById(R.id.PhoneNumET);
        rEmail = findViewById(R.id.EmailET) ;
        rPass = findViewById(R.id.PasswordET);
        rCPass = findViewById(R.id.ConPasswordET);

        mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),HomeActivity.class) );
            finish();

        }

        regisBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             String Email = rEmail.getText().toString().trim();
             String Password = rPass.getText().toString().trim();

             if(TextUtils.isEmpty(Email)){
                 rEmail.setError("Email is Required");
                 return;
             }
             if(TextUtils.isEmpty(Password)){
                 rPass.setError("Password is Required");
                 return;
             }
             if (Password.length() < 8){
                 rPass.setError("Password must be greater than or equal to 8 characters");
                 return;

             }

             mAuth.createUserWithEmailAndPassword(Email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                 @Override
                 public void onComplete(@NonNull Task<AuthResult> task) {
                 if (task.isSuccessful() ){
                     Toast.makeText(RegisterActivity.this, "Successfully Registered", Toast.LENGTH_LONG).show();
                     startActivity(new Intent(getApplicationContext(), HomeActivity.class) );
                 } else {
                     Toast.makeText(RegisterActivity.this, "Please fill-up the form", Toast.LENGTH_SHORT).show();

                 }

                 }
             }) ;

            }
        });
    }
}